package game;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;


public class SpikeBall extends Polygon {
	private int xVel = 4, yVel = 3 ;
	private static Point[] spikePoints = new Point[4];
	
	public SpikeBall(Point[] listed, int xPos, int yPos) {
		super(listed, new Point(xPos,yPos), 0);
		for (int i = 0; i < 4; i++) {
			spikePoints[i] = listed[i*9];
		}
	}
	
	/**
     * Inner class to handle collision responses
     */
    private class CollisionHandler {
        public void handlePaddleCollision(Paddle paddle) {
            yVel = -Math.abs(yVel);
            double hitPosition = (position.x - paddle.position.x) / paddle.getWidth();
            xVel = (int) (5 * (hitPosition - 0.5) * 2);
            rotate(20);
            position.y = paddle.position.y - 30;
        }

    }
	
	
	public void paint(Graphics brush) {
		Point[] ogList = this.getPoints();
		int[] xPoints = new int[ogList.length];
		int[] yPoints = new int[ogList.length];
		for (int i = 0; i < ogList.length; i++) {
			xPoints[i] = (int) ogList[i].getX();
			yPoints[i] = (int) ogList[i].getY();
		}
		brush.setColor(Color.blue);
		brush.fillPolygon(xPoints, yPoints, ogList.length);
		move();
	}
	
	// In the move() method, update the game over condition:
	public void move() {
	    if (!SpikePong.gameStarted || SpikePong.gameOver || SpikePong.gameWon) return;
	    
	    position.x += xVel;
	    position.y += yVel;
	    
	    // Wall collisions
	    if (position.x <= 0 || position.x + 50 >= 800) {
	        xVel *= -1;
	        rotate(20);
	    }
	    if (position.y <= 0) {
	        yVel *= -1;
	        rotate(20);
	    }
	    
	    // Check if ball passed behind the paddle (game over condition)
	    if (position.y + 50 >= 600) {
	        // Game over - stop the game
	        SpikePong.gameOver = true;
	        SpikePong.gameStarted = false;
	        return;
	    }
	}
	
	public void checkPaddleCollision(Paddle paddle) {
		Point[] ballPoints = this.getPoints();
		Point paddlePos = paddle.position;
		int paddleWidth = paddle.getWidth();
		int paddleHeight = paddle.getHeight();
		
		// rectangle collision detection between ball and paddle
		boolean collision = position.x + 30 >= paddlePos.x && 
		                   position.x <= paddlePos.x + paddleWidth &&
		                   position.y + 30 >= paddlePos.y && 
		                   position.y <= paddlePos.y + paddleHeight;
		
		if (collision) {
			// Reverse Y velocity to bounce
			yVel = -Math.abs(yVel); // Ensure it always goes upward
			
			// Adds horizontal movement based on where the ball hits the paddle
			double hitPosition = (position.x - paddlePos.x) / paddleWidth;
			xVel = (int) (5 * (hitPosition - 0.5) * 2); // -5 to 5 range
			
			rotate(20);
			
			// Adjust  to prevent sticking
			position.y = paddlePos.y - 30;
			
	        CollisionHandler handler = new CollisionHandler();
	        handler.handlePaddleCollision(paddle);
		}
	}
	
	public boolean checkBrickCollision(Brick brick) {
	    if (brick.isDestroyed()) return false;
	    
	    Point[] ballPoints = this.getPoints();
	    Point brickPos = brick.position;
	    int brickWidth = brick.getWidth();
	    int brickHeight = brick.getHeight();
	    
	    // Rectangle collision detection
	    boolean collision = position.x + 30 >= brickPos.x && 
	                       position.x <= brickPos.x + brickWidth &&
	                       position.y + 30 >= brickPos.y && 
	                       position.y <= brickPos.y + brickHeight;
	    
	    if (collision) {
	        // Determine which side of the brick was hit for better bounce physics
	        double ballCenterX = position.x + 15;
	        double ballCenterY = position.y + 15;
	        double brickCenterX = brickPos.x + brickWidth / 2.0;
	        double brickCenterY = brickPos.y + brickHeight / 2.0;
	        
	        // Calculate overlap on each side
	        double overlapLeft = (position.x + 30) - brickPos.x;
	        double overlapRight = (brickPos.x + brickWidth) - position.x;
	        double overlapTop = (position.y + 30) - brickPos.y;
	        double overlapBottom = (brickPos.y + brickHeight) - position.y;
	        
	        // Find the smallest overlap to determine collision side
	        double minOverlap = Math.min(Math.min(overlapLeft, overlapRight), 
	                                    Math.min(overlapTop, overlapBottom));
	        
	        if (minOverlap == overlapLeft || minOverlap == overlapRight) {
	            // Horizontal collision - reverse X velocity
	            xVel *= -1;
	        } else {
	            // Vertical collision - reverse Y velocity
	            yVel *= -1;
	        }
	        
	        rotate(20);
	        return true;
	    }
	    
	    return false;
	}
	
	
	
	// Getters for game over detection
	public double getY() {
		return position.y;
	}
	
	public double getHeight() {
		return 30; // Approximate ball height
	}
	
	public int getXVelocity() {
		return xVel;
	}
	
	public int getYVelocity() {
		return yVel;
	}
	
	public void setYVelocity(int yVel) {
		this.yVel = yVel;
	}
	
	public void setXVelocity(int xVel) {
		this.xVel = xVel;
	}
}