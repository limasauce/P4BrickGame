package game;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Interface for all brick types in the SpikePong game.
 * Provides methods for rendering, collisions, and state management
 * of bricks within the game. Implementing classes must provide functionality
 * for visual representation, collision handling, and tracking brick durability.
 * 
 */
public interface BrickInterface {
	
    /**
     * Renders the brick on the screen using the provided Graphics object.
     * The brick should only be visible if it hasn't been destroyed.
     * 
     * @param brush the Graphics object used for drawing the brick
     */
    void paint(Graphics brush);
    
    /**
     * Checks for collision between this brick and the game ball.
     * Handles the collision response including hit counting and destruction
     * when the brick's hit threshold is reached.
     * 
     * @param ball the SpikeBall to check for collision with
     * @return true if a collision occurred and was processed, false otherwise
     */
    boolean checkCollision(SpikeBall ball);
    
    /**
     * Determines whether the brick has been destroyed and should be removed
     * from gameplay. Destroyed bricks are not rendered and don't participate
     * in collision detection.
     * 
     * @return true if the brick is destroyed, false if it's still active
     */
    boolean isDestroyed();
    
    /**
     * Sets the destroyed state of the brick. Used to mark a brick as destroyed
     * when it has taken sufficient hits or for game state management.
     * 
     * @param destroyed the new destroyed state (true for destroyed, false for active)
     */
    void setDestroyed(boolean destroyed);
    
    /**
     * Gets the width of the brick. Used for collision detection
     * and rendering calculations.
     * 
     * @return the width of the brick
     */
    int getWidth();
    
    /**
     * Gets the height of the brick. Used for collision detection
     * and rendering calculations.
     * 
     * @return the height of the brick in pixels
     */
    int getHeight();
    
    /**
     * Gets the base color of the brick. The actual displayed color may vary
     * based on the brick's current hit status for visual feedback.
     * 
     * @return the base Color of the brick
     */
    Color getColor();
    
    /**
     * Gets the number of hits required to completely destroy this brick.
     * Different brick types may require different numbers of hits, allowing
     * for varied difficulty levels in the game.
     * 
     * @return the number of hits needed to destroy this brick
     */
    int getHitsRequired();
    
    /**
     * Gets the current number of hits this brick has sustained.
     * Used to track progress toward destruction and for visual feedback.
     * 
     * @return the current number of hits the brick has taken
     */
    int getCurrentHits();

}
