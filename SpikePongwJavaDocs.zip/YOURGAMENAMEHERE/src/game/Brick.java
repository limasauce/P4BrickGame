package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.*;


/**
 * Represents a destructible brick in the SpikePong game that can be hit by the ball.
 * Implements the BrickInterface and extends Polygon to provide geometric properties
 * and collision detection. Bricks have varying durability levels represented by
 * different colors and hit requirements.
 * 
 */
public class Brick extends Polygon implements BrickInterface {
    private int width;
    private int height;
    private boolean isDestroyed;
    private Color color;
    private int hitsRequired;
    private int currentHits;
    
    /**
     * Constructs a Brick with specified position, dimensions, color, and durability.
     * 
     * @param xPos the x coordinate position of the brick's top-left corner
     * @param yPos the y coordinate position of the brick's top-left corner
     * @param width the width of the brick 
     * @param height the height of the brick
     * @param color the base color representing the brick's difficulty level
     * @param hitsRequired the number of hits required to destroy the brick
     */
    public Brick(int xPos, int yPos, int width, int height, Color color, int hitsRequired) {
        super(createBrickShape(width, height), new Point(xPos, yPos), 0);
        this.width = width;
        this.height = height;
        this.color = color;
        this.hitsRequired = hitsRequired;
        this.currentHits = 0;
        this.isDestroyed = false;
    }
    
    /**
     * Constructs a Brick with default hit requirement (1 hit to destroy).
     * Provides backward compatibility for simpler brick creation.
     * 
     * @param xPos the x coordinate position of the brick's top left corner
     * @param yPos the y coordinate position of the brick's top left corner
     * @param width the width of the brick in pixels
     * @param height the height of the brick in pixels
     * @param color the base color of the brick
     */
    public Brick(int xPos, int yPos, int width, int height, Color color) {
        this(xPos, yPos, width, height, color, 1); // Default to 1 hit
    }
    
    /**
     * Creates the rectangular polygon shape for the brick.
     * 
     * @param width the width of the brick shape
     * @param height the height of the brick shape
     * @return an array of Points defining a rectangle with the specified dimensions
     */
    private static Point[] createBrickShape(int width, int height) {
        return new Point[] {
            new Point(0, 0),
            new Point(width, 0),
            new Point(width, height),
            new Point(0, height)
        };
    }
    
    /**
     * Renders the brick on the screen if it hasn't been destroyed.
     * The brick's color intensity decreases as it takes more hits,
     * providing visual feedback to the player about its durability.
     * 
     * @param brush the Graphics object used for drawing the brick
     */
    public void paint(Graphics brush) {
        if (!isDestroyed) {
            Point[] points = this.getPoints();
            int[] xPoints = new int[points.length];
            int[] yPoints = new int[points.length];
            
            for (int i = 0; i < points.length; i++) {
                xPoints[i] = (int) points[i].getX();
                yPoints[i] = (int) points[i].getY();
            }
            
            // Change color based on remaining hits for visual feedback
            Color displayColor = getDisplayColor();
            brush.setColor(displayColor);
            brush.fillPolygon(xPoints, yPoints, points.length);
            
            // Add border for better visibility
            brush.setColor(Color.black);
            brush.drawPolygon(xPoints, yPoints, points.length);
        }

    }
    
    /**
     * Calculates the display color based on the brick's current hit status.
     * Multiple hit bricks become progressively darker as they take damage,
     * providing visual feedback to the player about remaining durability.
     * 
     * @return the current display color adjusted for damage taken
     */
    private Color getDisplayColor() {
        if (hitsRequired == 1) return color; // No change for single-hit bricks
        
        // Calculate color intensity based on remaining hits
        float intensity = 1.0f - (float) currentHits / hitsRequired * 0.5f;
        int red = Math.min(255, (int) (color.getRed() * intensity));
        int green = Math.min(255, (int) (color.getGreen() * intensity));
        int blue = Math.min(255, (int) (color.getBlue() * intensity));
        
        return new Color(red, green, blue);
    }
    
    /**
     * Checks for collision with the ball and handles hit counting and scoring.
     * When a brick reaches its hit threshold, it is marked as destroyed and
     * points are awarded based on the brick's difficulty.
     * 
     * @param ball the SpikeBall to check for collision with
     * @return true if a collision occurred, false otherwise
     */
    public boolean checkCollision(SpikeBall ball) {
        if (isDestroyed) return false;
        
        boolean collision = ball.checkBrickCollision(this);
        
        if (collision) {
            currentHits++;
            
            if (currentHits >= hitsRequired) {
                isDestroyed = true;
                SpikePong.score += 10 * hitsRequired; // More points for harder bricks
            }
        }
        
        return collision;
    }
    
    /**
     * Checks if the brick has been destroyed.
     * 
     * @return true if the brick is destroyed, false if it's still active
     */
    public boolean isDestroyed() {
        return isDestroyed;
    }
    
    /**
     * Sets the destroyed state of the brick.
     * 
     * @param destroyed true to mark the brick as destroyed, false to make it active
     */
    public void setDestroyed(boolean destroyed) {
        this.isDestroyed = destroyed;
    }
    
    /**
     * Gets the width of the brick in pixels.
     * 
     * @return the width of the brick
     */
    public int getWidth() {
        return width;
    }
    
    /**
     * Gets the height of the brick in pixels.
     * 
     * @return the height of the brick
     */
    public int getHeight() {
        return height;
    }
    
    /**
     * Gets the base color of the brick.
     * 
     * @return the brick's base color
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Gets the number of hits required to destroy this brick.
     * 
     * @return the hits required for destruction
     */
    public int getHitsRequired() {
        return hitsRequired;
    }
    
    /**
     * Gets the current number of hits this brick has sustained.
     * 
     * @return the current hit count
     */
    public int getCurrentHits() {
        return currentHits;
    }
}