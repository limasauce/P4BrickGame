package game;

import java.awt.Color;
import java.awt.Graphics;



/**
 * Represents a paddle in the SpikePong game that can move horizontally
 * to hit the ball and prevent it from falling off the bottom of the screen.
 * Extends the Polygon class to utilize geometric properties and collision detection.
 * 
 */

public class Paddle extends Polygon {
    private int xVel = 0;
    private int width = 100;
    private int height = 20;    
    
    /**
     * Constructs a Paddle with specified dimensions and position.
     * 
     * @param xPos the x-coordinate position of the paddle
     * @param yPos the y-coordinate position of the paddle
     * @param width the width of the paddle in pixels
     * @param height the height of the paddle in pixels
     */
    public Paddle(int xPos, int yPos, int width, int height) {
        super(createPaddleShape(width, height), new Point(xPos, yPos), 0);
        this.width = width;
        this.height = height;
    }
    
    /**
     * Constructs a Paddle with default dimensions  at the specified position.
     * 
     * @param xPos the x-coordinate position of the paddle
     * @param yPos the y-coordinate position of the paddle
     */

    public Paddle(int xPos, int yPos) {
        super(createPaddleShape(100, 20), new Point(xPos, yPos), 0);
    }
    
    /**
     * Creates the rectangular shape for the paddle.
     * 
     * @param width the width of the paddle
     * @param height the height of the paddle
     * @return an array of Points defining the rectangular shape
     */
    private static Point[] createPaddleShape(int width, int height) {
        return new Point[] {
            new Point(0, 0),
            new Point(width, 0),
            new Point(width, height),
            new Point(0, height)
        };
    }
    
    
    /**
     * Draws the paddle on the screen using the provided Graphics object.
     * Also updates the paddle's position based on its velocity.
     * 
     * @param brush the Graphics object used for drawing
     */
    public void paint(Graphics brush) {
        Point[] points = this.getPoints();
        int[] xPoints = new int[points.length];
        int[] yPoints = new int[points.length];
        
        for (int i = 0; i < points.length; i++) {
            xPoints[i] = (int) points[i].getX();
            yPoints[i] = (int) points[i].getY();
        }
        
        brush.setColor(Color.white);
        brush.fillPolygon(xPoints, yPoints, points.length);
        move();
    }
    
    /**
     * Updates the paddle's position based on its velocity and ensures
     * it stays within the game boundaries (0 to 700 on x-axis).
     */
    public void move() {
        position.x += xVel;
        
        if (position.x < 0) {
            position.x = 0;
        } else if (position.x > 700) { 
            position.x = 700;
        }
    }
    
    /**
     * Sets the horizontal velocity of the paddle.
     * 
     * @param velocity the new velocity value (positive for right, negative for left)
     */
    public void setVelocity(int velocity) {
        this.xVel = velocity;
    }
    
    /**
     * Gets the current horizontal velocity of the paddle.
     * 
     * @return the current velocity value
     */
    public int getVelocity() {
        return xVel;
    }
    
    /**
     * Gets the width of the paddle.
     * 
     * @return the paddle width in pixels
     */
    public int getWidth() {
        return width;
    }
    
    /**
     * Gets the height of the paddle.
     * 
     * @return the paddle height in pixels
     */
    public int getHeight() {
        return height;
    }
}