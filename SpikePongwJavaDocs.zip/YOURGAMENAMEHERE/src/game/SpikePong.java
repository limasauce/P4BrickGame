package game;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * The main game class for SpikePong, a Breakout-style game where players
 * control a paddle to bounce a spiked ball and destroy colored bricks.
 * Extends the Game framework to handle rendering, input, and game logic.
 * 
 */
class SpikePong extends Game {
    
    /** Current player score by destroying bricks */
    static int score = 0;
    
    /** Collection of all active game elements for collision detection */
    protected static ArrayList<Polygon> allElements = new ArrayList<>();
    
    /** Variable indicating if the game has ended due to ball loss */
    protected static boolean gameOver = false;
    
    /** Variable showing if the main gameplay has started */
    protected static boolean gameStarted = false;
    
    /** showing if the player has won by destroying all bricks */
    protected static boolean gameWon = false;
    
    /** Array of points defining the spiked ball's geometric shape */
    private Point[] ballList;
    
    /** The main game ball that bounces and destroys bricks */
    private SpikeBall ball;
    
    /** Player controlled paddle for bouncing the ball */
    private Paddle paddle;

    // Variables for bricks
    /** 2D array containing all brick objects in the game */
    private Brick[][] bricks;
    
    /** Number of rows of bricks in the game layout */
    private int brickRows = 4;
    
    /** Number of columns of bricks in the game layout */
    private int brickCols = 8;
    
    /** Height in pixels for each brick */
    private int brickHeight = 30;
    
    /** Space in pixels between adjacent bricks */
    private int brickPadding = 2; 
    
    /** Vertical offset from top of screen to first brick row */
    private int brickOffsetTop = 50;
    
    /** Calculated width in pixels for each brick based on screen size */
    private int brickWidth; 

    // Start and restart buttons
    /** Rectangle defining the clickable area for the start button */
    private Rectangle startButton;
    
    /** Rectangle defining the clickable area for the restart button */
    private Rectangle restartButton;

    /**
     * Constructs the SpikePong game window and initializes all game components.
     * Sets up keyboard and mouse input listeners and prepares the game state.
     */
    public SpikePong() {
        super("SpikePong!", 800, 600);
        this.setFocusable(true);
        this.requestFocus();
        
        // Initialize buttons
        startButton = new Rectangle(300, 400, 200, 50);
        restartButton = new Rectangle(300, 470, 200, 50);
        
        initializeGame();
        
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (gameStarted && !gameOver && !gameWon) {
                    int key = e.getKeyCode();
                    if (key == KeyEvent.VK_LEFT) {
                        paddle.setVelocity(-5);
                    } else if (key == KeyEvent.VK_RIGHT) {
                        paddle.setVelocity(5);
                    }
                }
            }
            
            @Override
            public void keyReleased(KeyEvent e) {
                if (gameStarted && !gameOver && !gameWon) {
                    int key = e.getKeyCode();
                    if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
                        paddle.setVelocity(0);
                    }
                }
            }
        });
        

        // mouse listener with lambdas
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int mouseX = e.getX();
                int mouseY = e.getY();
                
                // Lambda for start button
                Runnable startAction = () -> {
                    if (!gameStarted && startButton.contains(mouseX, mouseY)) {
                        startGame();
                    }
                };
                
                // Lambda for restart button  
                Runnable restartAction = () -> {
                    if ((gameOver || gameWon) && restartButton.contains(mouseX, mouseY)) {
                        restartGame();
                    }
                };
                
                startAction.run();
                restartAction.run();
            }
        });
        
    }
    
	
    /**
     * Inner class to manage game state transitions
     */
    private class GameStateManager {
        public void transitionToStart() {
            gameStarted = true;
            gameOver = false;
            gameWon = false;
        }
        
        public void transitionToGameOver() {
            gameOver = true;
            gameStarted = false;
        }
        
        public boolean isGameActive() {
            return gameStarted && !gameOver && !gameWon;
        }
    }
    

    /**
     * Initializes or reinitializes all game elements to their starting state.
     * Creates the paddle, ball, and brick layout while resetting game status flags.
     */
    private void initializeGame() {
        // Initialize paddle
        paddle = new Paddle(350, 550, 100, 20);
        
        initializeBall();
        initializeBricks();
        
        // Reset game states
        gameStarted = false;
        gameOver = false;
        gameWon = false;
        score = 0;
    }
    
    private void startGame() {
        GameStateManager stateManager = new GameStateManager();
        stateManager.transitionToStart();
    }
    
    /**
     * Fully restarts the game by clearing all elements and reinitializing
     * the game state. Called when the player clicks the restart button.
     */
    private void restartGame() {
        allElements.clear();
        initializeGame();
        startGame();
    }
    
    /**
     * Creates the spiked ball with its complex geometric shape composed of
     * 36 points forming a circle with 4 prominent spikes at cardinal directions.
     * The ball is positioned at the center-top of the gameplay area.
     */
    private void initializeBall() {
        ballList = new Point[36];
        int radius = 15;
        int y = 0, x = 0;
        for (int i = 0; i < 36; i++) {
            double angle = (i * 10);
            if (angle == 0 || angle == 90 || angle == 180 || angle == 270) {
                angle = Math.toRadians(i*10);
                x = (int) (Math.round((radius+10) * Math.cos(angle)));
                y = (int) (Math.round((radius+10) * Math.sin(angle)));
            }
            else {
                angle = Math.toRadians(i * 10);
                x = (int) (Math.round(radius * Math.cos(angle)));
                y = (int) (Math.round(radius * Math.sin(angle)));
            }
            ballList[i] = new Point(x,y);
        }
        ball = new SpikeBall(ballList, 375, 250);
        allElements.add(ball);
    }
    
    /**
     * Creates the brick layout with color-coded difficulty levels.
     * Bricks are arranged in rows with increasing hit requirements:
     * Green (1 hit), Yellow (2 hits), Orange (3 hits), Red (4 hits).
     * Brick dimensions are calculated to fit the screen width exactly.
     */
    private void initializeBricks() {
        // Calculate brick width to fill the entire screen width
        int totalPadding = (brickCols + 1) * brickPadding;
        brickWidth = (width - totalPadding) / brickCols;
        
        bricks = new Brick[brickRows][brickCols];
        
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                int x = col * (brickWidth + brickPadding) + brickPadding;
                int y = row * (brickHeight + brickPadding) + brickOffsetTop;
                
                // Assign different difficulties based on row
                int hitsRequired;
                Color color;
                
                if (row == 0) { // Top row - Green bricks (easiest)
                    color = Color.GREEN;
                    hitsRequired = 1;
                } else if (row == 1) { // Second row - Yellow bricks
                    color = Color.YELLOW;
                    hitsRequired = 2;
                } else if (row == 2) { // Third row - Orange bricks
                    color = Color.ORANGE;
                    hitsRequired = 3;
                } else { // Bottom row - Red bricks (hardest)
                    color = Color.RED;
                    hitsRequired = 4;
                }
                
                bricks[row][col] = new Brick(x, y, brickWidth, brickHeight, color, hitsRequired);
            }
        }
    }
    
    /**
     * Performs collision detection between game elements each frame.
     * Checks for ball-paddle and ball-brick collisions and evaluates win condition.
     * Only processes collisions when the game is actively running.
     */
    private void checkCollisions() {
        if (!gameStarted || gameOver || gameWon) return;
        
        // Check paddle collision
        if (ball != null && paddle != null) {
            ball.checkPaddleCollision(paddle);
        }
        
        // Check brick collisions
        checkBrickCollisions();
        
        // Check win condition
        if (getRemainingBricks() == 0) {
            gameWon = true;
            gameStarted = false;
        }
    }
    
    /**
     * Iterates through all bricks and checks for collisions with the ball.
     * Each brick handles its own collision response and hit counting.
     */
    private void checkBrickCollisions() {
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                Brick brick = bricks[row][col];
                if (brick != null && !brick.isDestroyed()) {
                    brick.checkCollision(ball);
                }
            }
        }
    }
        
    /**
     * Counts and returns the number of bricks that haven't been destroyed.
     * Used to determine win condition and display progress to the player.
     * 
     * @return the number of bricks remaining in the game
     */
    private int getRemainingBricks() {
        int count = 0;
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                if (bricks[row][col] != null && !bricks[row][col].isDestroyed()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Draws a rectangular button with centered text on the screen.
     * Used for the start and restart buttons in menu screens.
     * 
     * @param brush the Graphics object used for rendering
     * @param button the Rectangle defining the button's position and size
     * @param text the text to display centered within the button
     */
    private void drawButton(Graphics brush, Rectangle button, String text) {
        // Draw button background
        brush.setColor(Color.GRAY);
        brush.fillRect(button.x, button.y, button.width, button.height);
        
        // Draw button border
        brush.setColor(Color.WHITE);
        brush.drawRect(button.x, button.y, button.width, button.height);
        
        // Draw button text
        brush.setFont(new Font("Arial", Font.BOLD, 20));
        FontMetrics metrics = brush.getFontMetrics();
        int textX = button.x + (button.width - metrics.stringWidth(text)) / 2;
        int textY = button.y + ((button.height - metrics.getHeight()) / 2) + metrics.getAscent();
        brush.drawString(text, textX, textY);
    }
    
    /**
     * Main rendering method called each frame to draw the entire game state.
     * Handles different screen states: start menu, active gameplay, game over, and win screens.
     * Also updates game logic and checks for collisions.
     * 
     * @param brush the Graphics object used for all rendering operations
     */
    public void paint(Graphics brush) {
        brush.setColor(Color.black);
        brush.fillRect(0, 0, width, height);
        
        // Start Screen
        if (!gameStarted && !gameOver && !gameWon) {
            brush.setColor(Color.WHITE);
            brush.setFont(new Font("Arial", Font.BOLD, 48));
            brush.drawString("SPIKE PONG", width/2 - 150, 150);
            
            brush.setFont(new Font("Arial", Font.PLAIN, 24));
            brush.drawString("Destroy all bricks to win!", width/2 - 140, 200);
            brush.drawString("Use LEFT and RIGHT arrows to move paddle", width/2 - 220, 250);
            brush.drawString("Don't let the ball fall!", width/2 - 120, 300);
            
            // Draw start button
            drawButton(brush, startButton, "START GAME");
            return;
        }
        
        // Game Over Screen
        if (gameOver) {
            brush.setColor(Color.RED);
            brush.setFont(new Font("Arial", Font.BOLD, 48));
            brush.drawString("GAME OVER", width/2 - 150, 200);
            
            brush.setColor(Color.WHITE);
            brush.setFont(new Font("Arial", Font.PLAIN, 24));
            brush.drawString("Final Score: " + score, width/2 - 80, 270);
            brush.drawString("Bricks Destroyed: " + (brickRows * brickCols - getRemainingBricks()) + "/" + (brickRows * brickCols), 
                           width/2 - 120, 320);
            
            // Draw restart button
            drawButton(brush, restartButton, "PLAY AGAIN");
            return;
        }
        
        // Win Screen
        if (gameWon) {
            brush.setColor(Color.GREEN);
            brush.setFont(new Font("Arial", Font.BOLD, 48));
            brush.drawString("YOU WIN!", width/2 - 120, 200);
            
            brush.setColor(Color.WHITE);
            brush.setFont(new Font("Arial", Font.PLAIN, 24));
            brush.drawString("Final Score: " + score, width/2 - 80, 270);
            brush.drawString("All bricks destroyed!", width/2 - 120, 320);
            
            // Draw restart button
            drawButton(brush, restartButton, "PLAY AGAIN");
            return;
        }
        
        // Main Game Screen
        // Paints bricks
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                if (bricks[row][col] != null) {
                    bricks[row][col].paint(brush);
                }
            }
        }
        
        // Paint game objects
        if (ball != null) {
            ball.paint(brush);
        }
        if (paddle != null) {
            paddle.paint(brush);
        }

        // Check all collisions
        checkCollisions();

        brush.setColor(Color.white);
        brush.drawString("Score: " + score, 10, 30);
        brush.drawString("Bricks remaining: " + getRemainingBricks(), 10, 50);
    }  
    
    /**
     * Main entry point that launches the SpikePong game.
     * Creates the game instance and starts the rendering loop.
     * 
     * @param args not really used tho
     */
    public static void main(String[] args) {
        SpikePong game = new SpikePong();
        game.repaint();
    }
}