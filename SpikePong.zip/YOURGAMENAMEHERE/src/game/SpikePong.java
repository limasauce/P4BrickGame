package game;

/*
CLASS: YourGameNameoids
DESCRIPTION: Extending Game, YourGameName is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.

*/
import java.awt.*;
import java.awt.event.*;

class SpikePong extends Game {
	static int counter = 0;
	
	private Point[] ballList = new Point[36];
	{
		int radius = 15;
		int y = 0, x = 0;
		for (int i = 0; i < 36; i++) {
			double angle = (i * 10);
			if (angle == 0 || angle == 90 || angle == 180 || angle == 270) {
				angle = Math.toRadians(i*10);
				x = (int) (Math.round((radius+10) * Math.cos(angle)));
				y = (int) (Math.round((radius+10) * Math.sin(angle)));
			}
			else {
			angle = Math.toRadians(i * 10);
			x = (int) (Math.round(radius * Math.cos(angle)));
			y = (int) (Math.round(radius * Math.sin(angle)));
			}
			ballList[i] = new Point(x,y);
		}
	}
	private SpikeBall ball = new SpikeBall(ballList, 375, 250);

  public SpikePong() {
    super("SpikePong!",800,600);
    this.setFocusable(true);
	this.requestFocus();
  }
  
	public void paint(Graphics brush) {
    	brush.setColor(Color.black);
    	brush.fillRect(0,0,width,height);
    	ball.paint(brush);

    	// sample code for printing message for debugging
    	// counter is incremented and this message printed
    	// each time the canvas is repainted
    	counter++;
    	brush.setColor(Color.white);
    	brush.drawString("Counter is " + counter,10,10);
  }
  
	public static void main (String[] args) {
   		SpikePong a = new SpikePong();
		a.repaint();
  }
}