package game;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;


public class SpikeBall extends Polygon {
	private int xVel = 3, yVel = 2;
	private static Point[] spikePoints = new Point[4];
	
	public SpikeBall(Point[] listed, int xPos, int yPos) {
		super(listed, new Point(xPos,yPos), 0);
		for (int i = 0; i < 4; i++) {
			spikePoints[i] = listed[i*9];
		}
	}
	
	public void paint(Graphics brush) {
		Point[] ogList = this.getPoints();
		int[] xPoints = new int[ogList.length];
		int[] yPoints = new int[ogList.length];
		for (int i = 0; i < ogList.length; i++) {
			xPoints[i] = (int) ogList[i].getX();
			yPoints[i] = (int) ogList[i].getY();
		}
		brush.setColor(Color.blue);
		brush.fillPolygon(xPoints, yPoints, ogList.length);
		move(SpikePong.allElements);
	}
	
	public void move(ArrayList<Polygon> allElements) {
		position.x += xVel;
		position.y += yVel;
		if (position.x <= 0 || position.x + 50 >= 800) {
    		xVel *= -1;
    		rotate(20);
    	}
    	if (position.y <= 0 || position.y + 50 >= 600) {
    		//get rid of second half of ||
    		yVel *= -1;
    		rotate(20);
    	}
	}
	
	private Collision collisionHandler = new Collision();
	
	public void checkCollision(Polygon other) {
		collisionHandler.collider(other);
	}
	
	private class Collision {
		public void collider(Polygon other) {
//			if (other instanceof Paddle) { uncomment later
//				Point[] thisPoints = SpikeBall.this.getPoints();
//				collidedWithObj(other, thisPoints);
//			}
//			else if (other instanceof Brick) { uncomment later
//				Point[] thisPoints = SpikeBall.spikePoints;
//				collidedWithObj(other, thisPoints);
//				//break brick
//				//add score
//			}
		}
		
		public void collidedWithObj(Polygon other, Point[] thisPoints) {
			for (Point p : thisPoints) {
				if (other.contains(p)) {
					yVel *= -1;
					rotate(20);
					return;
				}
			}
		}
	}
}
