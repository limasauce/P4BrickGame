package game;

import java.awt.Color;
import java.awt.Graphics;

//DO I MAKE THE SPIKES A DIFFERENT CLASS FOR COLLISIONS
//make it an inner class i think

public class SpikeBall extends Polygon {
	private int xVel = 3, yVel = 2;
	
	public SpikeBall(Point[] listed, int xPos, int yPos) {
		super(listed, new Point(xPos,yPos), 0);
		Spikes collider = new Spikes(25, 10, xPos, yPos);
	}
	
	public void paint(Graphics brush) {
		Point[] ogList = this.getPoints();
		int[] xPoints = new int[ogList.length];
		int[] yPoints = new int[ogList.length];
		for (int i = 0; i < ogList.length; i++) {
			xPoints[i] = (int) ogList[i].getX();
			yPoints[i] = (int) ogList[i].getY();
		}
		brush.setColor(Color.blue);
		brush.fillPolygon(xPoints, yPoints, ogList.length);
		move();
	}
	
	public void move() {
		position.x += xVel;
		position.y += yVel;
		if (position.x <= 0 || position.x + 50 >= 800) {
    		xVel *= -1;
    		rotate(20);
    	}
    	if (position.y <= 0 || position.y + 50 >= 600) {
    		//get rid of second half of ||
    		yVel *= -1;
    		rotate(20);
    	}
	}
	
	//inner class for spike with block collisions
	class Spikes extends Polygon{		
		private Spikes(int outRadius, int inRadius, int xPos, int yPos) {
			super(makeSpikes(outRadius, inRadius), new Point(xPos, yPos), 0);
		}
		
		public static Point[] makeSpikes(int outRadius, int inRadius) {
			Point[] spikePoints = new Point[8];
			for (int i = 0; i < 8; i++) {
				double angle = i * 45;
				int currentRadius = outRadius;
				if (i % 2 == 0) {
					currentRadius = inRadius;
				}
				int x = (int) (Math.round(currentRadius * Math.cos(angle)));
				int y = (int) (Math.round(currentRadius * Math.sin(angle)));
				spikePoints[i] = new Point(x,y);
			}
			return spikePoints;
		}
	}
	
}
