package game;


import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class SpikePong extends Game {
    static int counter = 0;
	protected static ArrayList<Polygon> allElements = new ArrayList<>();
    
    private Point[] ballList;
    private SpikeBall ball;
    private Point[] paddleShape = new Point[] {
        new Point(0, 0),
        new Point(100, 0),
        new Point(100, 20),
        new Point(0, 20)
    };
    private Paddle paddle = new Paddle(paddleShape, 350, 550);

    //Variables for bricks
    private Brick[][] bricks;
    private int brickRows = 4;
    private int brickCols = 8;
    private int brickHeight = 30;
    private int brickPadding = 2; 
    private int brickOffsetTop = 50;
    private int brickWidth; 

    public SpikePong() {
        super("SpikePong!", 800, 600);
        this.setFocusable(true);
        this.requestFocus();
        initializeBall();
        initializeBricks();
        
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_LEFT) {
                    paddle.setVelocity(-5); // Move left
                } else if (key == KeyEvent.VK_RIGHT) {
                    paddle.setVelocity(5); // Move right
                }
            }
            
            @Override
            public void keyReleased(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
                    paddle.setVelocity(0); // Stop moving when key is released
                }
            }
        });
        
    
    }
    
    private void initializeBall() {
        ballList = new Point[36];
        int radius = 15;
        int y = 0, x = 0;
        for (int i = 0; i < 36; i++) {
            double angle = (i * 10);
            if (angle == 0 || angle == 90 || angle == 180 || angle == 270) {
                angle = Math.toRadians(i*10);
                x = (int) (Math.round((radius+10) * Math.cos(angle)));
                y = (int) (Math.round((radius+10) * Math.sin(angle)));
            }
            else {
                angle = Math.toRadians(i * 10);
                x = (int) (Math.round(radius * Math.cos(angle)));
                y = (int) (Math.round(radius * Math.sin(angle)));
            }
            ballList[i] = new Point(x,y);
        }
        ball = new SpikeBall(ballList, 375, 250);
        allElements.add(ball);
    }
    
    //method takes variables, double loops in order to creates brick [row][column]
    private void initializeBricks() {
        // Calculate brick width to fill the entire screen width
        int totalPadding = (brickCols + 1) * brickPadding;
        brickWidth = (width - totalPadding) / brickCols;
        
        bricks = new Brick[brickRows][brickCols];
        Color[] rowColors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN};
        
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                int x = col * (brickWidth + brickPadding) + brickPadding;
                int y = row * (brickHeight + brickPadding) + brickOffsetTop;
                bricks[row][col] = new Brick(x, y, brickWidth, brickHeight, rowColors[row]);
            }
        }
    }
    
    private void checkBrickCollisions() {
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                Brick brick = bricks[row][col];
                if (brick != null && !brick.isDestroyed()) {
                    if (brick.checkCollision(ball)) {

                    }
                }
            }
        }
    }
        
    private int getRemainingBricks() {
        int count = 0;
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                if (bricks[row][col] != null && !bricks[row][col].isDestroyed()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    public void paint(Graphics brush) {
        brush.setColor(Color.black);
        brush.fillRect(0, 0, width, height);
        
        // Paints bricks
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                if (bricks[row][col] != null) {
                    bricks[row][col].paint(brush);
                }
            }
        }
        
        // Paint game objects
        if (ball != null) {
            ball.paint(brush);
        }
        if (paddle != null) {
            paddle.paint(brush);
        }

        // Check collisions between ball and bricks
        if (ball != null) {
            checkBrickCollisions();
        }

        counter++;
        brush.setColor(Color.white);
        brush.drawString("Counter is " + counter, 10, 10);
        if (bricks != null) {
            brush.drawString("Bricks remaining: " + getRemainingBricks(), 10, 30);
        }
    }  
    
    public static void main(String[] args) {
        SpikePong game = new SpikePong();
        game.repaint();
    }
}