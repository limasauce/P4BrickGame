package game;

import java.awt.Color;
import java.awt.Graphics;

public class Paddle extends Polygon {
    private int xVel = 0;
    private int width = 100;
    private int height = 20;
    
    public Paddle(Point[] shape, int xPos, int yPos) {
        super(shape, new Point(xPos, yPos), 0);
    }
    
    public Paddle(int xPos, int yPos, int width, int height) {
        super(createPaddleShape(width, height), new Point(xPos, yPos), 0);
        this.width = width;
        this.height = height;
    }
    
    public Paddle(int xPos, int yPos) {
        super(createPaddleShape(100, 20), new Point(xPos, yPos), 0);
    }
    
    private static Point[] createPaddleShape(int width, int height) {
        return new Point[] {
            new Point(0, 0),
            new Point(width, 0),
            new Point(width, height),
            new Point(0, height)
        };
    }
    
    public void paint(Graphics brush) {
        Point[] points = this.getPoints();
        int[] xPoints = new int[points.length];
        int[] yPoints = new int[points.length];
        
        for (int i = 0; i < points.length; i++) {
            xPoints[i] = (int) points[i].getX();
            yPoints[i] = (int) points[i].getY();
        }
        
        brush.setColor(Color.white);
        brush.fillPolygon(xPoints, yPoints, points.length);
        move();
    }
    
    public void move() {
        position.x += xVel;
        
        if (position.x < 0) {
            position.x = 0;
        } else if (position.x > 700) { 
            position.x = 700;
        }
    }
    
    public void setVelocity(int velocity) {
        this.xVel = velocity;
    }
    
    public int getVelocity() {
        return xVel;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
}