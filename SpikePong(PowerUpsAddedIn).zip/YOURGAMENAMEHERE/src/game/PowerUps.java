package game;

import java.awt.Color;
import java.awt.Graphics;

public interface PowerUps {
	
	void applyToBall(SpikeBall ball);
	void paint(Graphics brush);
	
	class SpeedUp extends Polygon implements PowerUps{
		private boolean notDeleted = true;
		
		public SpeedUp(Point[] inShape, Point inPosition, double inRotation) {
			super(inShape, inPosition, inRotation);
		}
		
		@Override
		public void applyToBall(SpikeBall ball) {
			ball.setXVel(5);
			ball.setYVel(4);
			try {
				Thread.sleep(300);
			} catch (Exception e) {}
			ball.setXVel(3);
			ball.setYVel(2);
		}
		
		@Override
		public void paint(Graphics brush) {
			if (notDeleted) {
				Point[] ogList = this.getPoints();
				int[] xPoints = new int[ogList.length];
				int[] yPoints = new int[ogList.length];
				for (int i = 0; i < ogList.length; i++) {
					xPoints[i] = (int) ogList[i].getX();
					yPoints[i] = (int) ogList[i].getY();
				}
				brush.setColor(Color.magenta);
				brush.fillPolygon(xPoints, yPoints, ogList.length);
				this.position.y += 2;
				if (this.position.y >= 600) {
					notDeleted = false;
				}
			}
		}
		
	}
	
	class NoColliding extends Polygon implements PowerUps{
		private boolean notDeleted = true;

		public NoColliding(Point[] inShape, Point inPosition, double inRotation) {
			super(inShape, inPosition, inRotation);
		}
		
		@Override
		public void applyToBall(SpikeBall ball) {
			ball.setCanCollide(false);
			try {
				Thread.sleep(300);
			} catch (Exception e) {}
			ball.setCanCollide(true);
		}
		
		@Override
		public void paint(Graphics brush) {
			if (notDeleted) {
				Point[] ogList = this.getPoints();
				int[] xPoints = new int[ogList.length];
				int[] yPoints = new int[ogList.length];
				for (int i = 0; i < ogList.length; i++) {
					xPoints[i] = (int) ogList[i].getX();
					yPoints[i] = (int) ogList[i].getY();
				}
				brush.setColor(Color.magenta);
				brush.fillPolygon(xPoints, yPoints, ogList.length);
				this.position.y += 2;
				if (this.position.y >= 600) {
					notDeleted = false;
				}
			}
		}
		
	}

}
