package game;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class SpikePong extends Game {
    static int counter = 0;
    static int score = 0;
    protected static ArrayList<Polygon> allElements = new ArrayList<>();
    protected static boolean gameOver = false;
    
    private Point[] ballList;
    private SpikeBall ball;
    private Paddle paddle;

    //Variables for bricks
    private Brick[][] bricks;
    private int brickRows = 4;
    private int brickCols = 8;
    private int brickHeight = 30;
    private int brickPadding = 2; 
    private int brickOffsetTop = 50;
    private int brickWidth; 

    public SpikePong() {
        super("SpikePong!", 800, 600);
        this.setFocusable(true);
        this.requestFocus();
        
        // Initialize paddle first
        paddle = new Paddle(350, 550, 100, 20);
        
        initializeBall();
        initializeBricks();
        
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_LEFT) {
                    paddle.setVelocity(-5); // Move left
                } else if (key == KeyEvent.VK_RIGHT) {
                    paddle.setVelocity(5); // Move right
                }
            }
            
            @Override
            public void keyReleased(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
                    paddle.setVelocity(0); // Stop moving when key is released
                }
            }
        });
    }
    
    private void initializeBall() {
        ballList = new Point[36];
        int radius = 15;
        int y = 0, x = 0;
        for (int i = 0; i < 36; i++) {
            double angle = (i * 10);
            if (angle == 0 || angle == 90 || angle == 180 || angle == 270) {
                angle = Math.toRadians(i*10);
                x = (int) (Math.round((radius+10) * Math.cos(angle)));
                y = (int) (Math.round((radius+10) * Math.sin(angle)));
            }
            else {
                angle = Math.toRadians(i * 10);
                x = (int) (Math.round(radius * Math.cos(angle)));
                y = (int) (Math.round(radius * Math.sin(angle)));
            }
            ballList[i] = new Point(x,y);
        }
        ball = new SpikeBall(ballList, 375, 250);
        allElements.add(ball);
    }
    
    private void initializeBricks() {
        // Calculate brick width to fill the entire screen width
        int totalPadding = (brickCols + 1) * brickPadding;
        brickWidth = (width - totalPadding) / brickCols;
        
        bricks = new Brick[brickRows][brickCols];
        Color[] rowColors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN};
        
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                int x = col * (brickWidth + brickPadding) + brickPadding;
                int y = row * (brickHeight + brickPadding) + brickOffsetTop;
                bricks[row][col] = new Brick(x, y, brickWidth, brickHeight, rowColors[row]);
            }
        }
    }
    
    private void checkCollisions() {
        // Check paddle collision
        if (ball != null && paddle != null) {
            ball.checkPaddleCollision(paddle);
        }
        
        // Check brick collisions
        checkBrickCollisions();
    }
    
    private void checkBrickCollisions() {
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                Brick brick = bricks[row][col];
                if (brick != null && !brick.isDestroyed()) {
                    brick.checkCollision(ball);
                }
            }
        }
    }
        
    private int getRemainingBricks() {
        int count = 0;
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                if (bricks[row][col] != null && !bricks[row][col].isDestroyed()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    public void paint(Graphics brush) {
        brush.setColor(Color.black);
        brush.fillRect(0, 0, width, height);
        
        // Game over screen
        if (gameOver) {
            brush.setColor(Color.white);
            brush.setFont(new Font("Arial", Font.BOLD, 36));
            brush.drawString("GAME OVER", width/2 - 100, height/2);
            brush.setFont(new Font("Arial", Font.PLAIN, 18));
            brush.drawString("Final Score: " + score, width/2 - 80, height/2 + 40);
            return;
        }
        
        // Paints bricks
        for (int row = 0; row < brickRows; row++) {
            for (int col = 0; col < brickCols; col++) {
                if (bricks[row][col] != null) {
                    bricks[row][col].paint(brush);
                }
            }
        }
        
        // Paint game objects
        if (ball != null) {
            ball.paint(brush);
        }
        if (paddle != null) {
            paddle.paint(brush);
        }

        // Check all collisions
        checkCollisions();

        counter++;
        brush.setColor(Color.white);
        brush.drawString("Counter: " + counter, 10, 10);
        brush.drawString("Score: " + score, 10, 30);
        brush.drawString("Bricks remaining: " + getRemainingBricks(), 10, 50);
    }  
    
    public static void main(String[] args) {
        SpikePong game = new SpikePong();
        game.repaint();
    }
}