package game;

import java.awt.Color;
import java.awt.Graphics;

public class Brick extends Polygon {
    private int width;
    private int height;
    private boolean isDestroyed;
    private Color color;
    
    public Brick(int xPos, int yPos, int width, int height, Color color) {
        super(createBrickShape(width, height), new Point(xPos, yPos), 0);
        this.width = width;
        this.height = height;
        this.color = color;
        this.isDestroyed = false;
    }
    
    private static Point[] createBrickShape(int width, int height) {
        return new Point[] {
            new Point(0, 0),
            new Point(width, 0),
            new Point(width, height),
            new Point(0, height)
        };
    }
    
    public void paint(Graphics brush) {
        if (!isDestroyed) {
            Point[] points = this.getPoints();
            int[] xPoints = new int[points.length];
            int[] yPoints = new int[points.length];
            
            for (int i = 0; i < points.length; i++) {
                xPoints[i] = (int) points[i].getX();
                yPoints[i] = (int) points[i].getY();
            }
            
            brush.setColor(color);
            brush.fillPolygon(xPoints, yPoints, points.length);
            
            // Add border for better visibility
            brush.setColor(Color.black);
            brush.drawPolygon(xPoints, yPoints, points.length);
        }
    }
    
    // Check collision with ball and handle destruction
    public boolean checkCollision(SpikeBall ball) {
        if (isDestroyed) return false;
        
        boolean collision = ball.checkBrickCollision(this);
        
        if (collision) {
            isDestroyed = true;
            SpikePong.score += 10; // Add score when brick is destroyed
        }
        
        return collision;
    }
    
    // Getters
    public boolean isDestroyed() {
        return isDestroyed;
    }
    
    public void setDestroyed(boolean destroyed) {
        this.isDestroyed = destroyed;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
}